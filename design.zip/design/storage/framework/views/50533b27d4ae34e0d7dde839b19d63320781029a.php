<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

        <style>
            <?php echo $__env->make('styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </style>

    </head>
    <body>
        <div class="container">
            <?php echo $__env->make('menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="authorization-form">
                <h1>Please authorize for using admin rights</h1>
                <form action="#" class="authorize-form">
                    <?php echo csrf_field(); ?>
                    <label for="email">Enter your email</label>
                    <input type="email" id="email" placeholder="example@mail.com">
                    <br>
                    <label for="pass">Enter your password</label>
                    <input type="password" id="pass" placeholder="password">
                    <br>
                    <input type="submit" value="Enter" class="authorize-button">
                    <br>
                    <a href="#">Forgot your password?</a>
                </form>
            </div>
        </div>
    </body>
</html>
<?php /**PATH C:\Users\Snega\design\resources\views/authorizationPage.blade.php ENDPATH**/ ?>