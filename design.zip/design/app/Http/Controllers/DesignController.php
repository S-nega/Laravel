<?php

namespace App\Http\Controllers;

use App\Models\Design;
use App\Models\Image;
use App\Models\User;
use Illuminate\Http\Request;

class DesignController extends Controller
{
    public function index(){
//        $word = 'Hello World!';
//        $bool = true;
//
//        $array = [
//            ['name' => 'Max'],
//            ['name' => 'Tony'],
//            ['name' => 'Anna'],
//            ['name' => 'Igor']
//        ];
//        return view('design', ['test' => $word, 'bool' => $bool, 'names' => $array]);
//
//        $designs =Design::all();
//        return view('design', [
//            'design' =>$designs
//        ]);
        $designs = Design::with('category')->get();
        return view('design', [
            'design' => $designs
        ]);
    }

    public function authorizeP(){
        return view('authorizationPage');
    }
    public function servicesP(){
        return view('servicesPage');
    }
    public function ourProductsP(){
        return view('ourProductsPage');
    }
    public function contactsP(){
        return view('contactsPage');
    }
    public function callbackP(){
        return view('callbackPage');
    }

        public function create(Request $request){
        $design = new Design();
        $design->task = $request->get('task');

        $design->save();
        return redirect('/design-page');
    }

    public function delete(Design $design){
        $design->delete();

        return redirect('/design-page');
    }
//
//    public function imageSearch(Image $image){
//        if (images.project_id == projects.id()){
//            return $image;
//        }
//        return null;
//    }
}
