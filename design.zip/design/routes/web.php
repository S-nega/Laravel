<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route::get('/', function () {
//    return view('welcome');
//});

Route::get('/design-page', [\App\Http\Controllers\DesignController::class, 'index']);
Route::get('/authorization-page', [\App\Http\Controllers\DesignController::class, 'authorizeP'])->name('authorizeP');
Route::get('/services', [\App\Http\Controllers\DesignController::class, 'servicesP'])->name('servicesP');
Route::get('/ourProducts', [\App\Http\Controllers\DesignController::class, 'ourProductsP'])->name('ourProductsP');
Route::get('/contacts', [\App\Http\Controllers\DesignController::class, 'contactsP'])->name('contactsP');
Route::get('/callback', [\App\Http\Controllers\DesignController::class, 'callbackP'])->name('callbackP');
//Route::get('/authorization-page', function (){
//    return view('authorizationPage');
//});
//Route::post('/todo/create', [\App\Http\Controllers\DesignController::class, 'create']);
//Route::get('/todo/done/{todo}', [\App\Http\Controllers\DesignController::class, 'done']);
//Route::get('/todo/delete/{todo}', [\App\Http\Controllers\DesignController::class, 'delete']);
